import os

BOT_TOKEN = os.getenv("BOT_TOKEN")
GOLD_API_KEY = os.getenv("GOLD_API_KEY")
CHAT_ID = os.getenv("CHAT_ID")

USD_TO_QAR = 3.64